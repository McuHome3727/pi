#!/bin/bash
sudo /opt/tinyUPS/tinyUPSshutdown.py &
exit 0
