# ATtinyWatch
ATtiny85 Watch Core

![Prototype](https://content.instructables.com/ORIG/FUG/98WA/IIM1V9D2/FUG98WAIIM1V9D2.jpg?auto=webp&crop=1.2%3A1&frame=1&width=306)
![Prototype](https://content.instructables.com/ORIG/F7Y/XUDD/IKH5GSX6/F7YXUDDIKH5GSX6.jpg?auto=webp&crop=1.2%3A1&frame=1&width=306)

Please find more details at instructables:

http://www.instructables.com/id/ATtiny-Watch-Core/

http://www.instructables.com/id/ATtiny85-Ring-Watch/

