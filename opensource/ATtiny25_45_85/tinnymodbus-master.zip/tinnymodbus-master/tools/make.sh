#!/bin/bash

c++ modbus-flash.cpp -o modbus-flash -Wall -Werror

